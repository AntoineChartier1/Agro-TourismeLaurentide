<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Entreprise extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'description',
    ];

    public function forfaits()
    {
        return $this->morphToMany(Forfait::class, "forfaitable", "forfaitables");
    }
    public function accomodations()
    {
        return $this->belongsToMany(Accomodation::class, 'entreprise_accomodation', 'entreprise_id', 'accomodation_id');
    }
    public function typecategories()
    {
        return $this->belongsToMany(TypeCategorie::class, 'entreprise_type_categorie', 'entreprise_id', 'type_categorie_id');
    }
    public function categories()
    {
        return $this->belongsToMany(Categorie::class, 'entreprise_categorie', 'entreprise_id', 'categorie_id');
    }
    public function users()
    {
        return $this->belongsToMany(User::class, 'entreprise_user', 'entreprise_id', 'user_id');
    }
}
