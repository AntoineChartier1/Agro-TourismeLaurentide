<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Forfait extends Model
{
    use HasFactory;

    public function entreprises()
    {
        return $this->morphedByMany(Entreprise::class, "forfaitable", "forfaitables");
    }
    public function activites()
    {
        return $this->morphedByMany(Activite::class, "forfaitable", "forfaitables");
    }
}
