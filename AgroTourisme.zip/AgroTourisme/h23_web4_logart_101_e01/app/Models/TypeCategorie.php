<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TypeCategorie extends Model
{
    use HasFactory;

    public function entreprises()
    {
        return $this->belongsToMany(Entreprise::class, 'entreprise_type_categorie', 'type_categorie_id', 'entreprise_id');
    }
}
