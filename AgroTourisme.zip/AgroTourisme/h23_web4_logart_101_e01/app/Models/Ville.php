<?php

namespace App\Models;

use App\Models\User as ModelsUser;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ville extends Model
{
    use HasFactory;

    public function mrc()
    {
        return $this->belongsTo(Mrc::class);
    }
}

class User extends Model
{
    use HasFactory;

    function villes()
    {
        return $this->hasMany(User::class, 'user_id');
    }
}
