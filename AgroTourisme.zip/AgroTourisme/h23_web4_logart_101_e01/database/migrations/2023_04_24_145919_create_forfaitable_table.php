<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateForfaitableTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('forfaitables', function (Blueprint $table) {
            $table->id();
            $table->foreignId("forfait_id")->constrained()->cascadeOnDelete();
            $table->integer("forfaitable_id");
            $table->string("forfaitable_type");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('forfaitables');
    }
}
