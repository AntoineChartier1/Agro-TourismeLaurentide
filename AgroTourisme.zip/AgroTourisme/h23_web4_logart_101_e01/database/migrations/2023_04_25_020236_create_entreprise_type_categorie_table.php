<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEntrepriseTypeCategorieTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('entreprise_type_categorie', function (Blueprint $table) {
            $table->Integer('entreprise_id');
            $table->Integer('type_categorie_id');
            $table->foreign('entreprise_id')->references('id')->on('entreprises')->onDelete('cascade');
            $table->foreign('type_categorie_id')->references('id')->on('type_categories')->onDelete('cascade');
            $table->primary(['entreprise_id', 'type_categorie_id']);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('entreprise_type_categorie');
    }
}
