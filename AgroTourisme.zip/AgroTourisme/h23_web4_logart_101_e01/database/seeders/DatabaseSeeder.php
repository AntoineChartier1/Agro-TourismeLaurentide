<?php

namespace Database\Seeders;

use App\Models\Entreprise;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
         \App\Models\User::factory(10)->create();
         $entreprises = \App\Models\Entreprise::factory(10)->create();
         $activites = \App\Models\Activite::factory(10)->create();
         $forfaits = \App\Models\Forfait::factory(10)->create();
         $forfaits[0]->entreprises()->attach($entreprises[5]);
         $forfaits[0]->activites()->attach($activites[1]);
         $entreprises[5]->forfaits()->attach($forfaits[5]);
         $activites[1]->forfaits()->attach($forfaits[1]);
        //  $entreprises->each(function ($entreprise))
    }
}
