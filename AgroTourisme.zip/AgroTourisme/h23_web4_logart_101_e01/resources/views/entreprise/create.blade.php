<form action="{{ route('entreprise.store') }}" method="POST" >
    @csrf

    <label for="name">Name:</label>
    <input type="text" name="name" id="name">
    <br/>

    <label for="description">Description:</label>
    <textarea name="description" id="description"></textarea>
    <br/>

    <button type="submit">Ajouter</button>
</form>
