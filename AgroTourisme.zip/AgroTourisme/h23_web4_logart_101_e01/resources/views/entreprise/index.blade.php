@extends('layouts.app')
@section ('contenu')
<h2>je suis dans la section contenu des entreprise</h2>
@include('entreprise.create')


@endsection
