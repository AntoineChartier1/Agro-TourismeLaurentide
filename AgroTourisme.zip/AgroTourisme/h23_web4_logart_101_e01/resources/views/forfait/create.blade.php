@extends('layouts.app')
@section('contenu')
<h1>Creer un forfait</h1>

<form action="{{ route('forfait.store') }}" method="POST">
    @include('forfait.form')
</form>


@endsection
