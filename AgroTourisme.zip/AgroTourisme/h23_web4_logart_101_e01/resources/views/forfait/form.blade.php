@csrf
@if(count($errors))
<div class="errors"> Il y a des erreurs dans le formulaire</div>
@endif

<div>
    <label for="name">Nom</label>
    <span><input required type="text" name="name" id="name" value="NomDuForfait"></span>
    @if($errors->has('name'))
        <span class="error">{{$errors->first('name')}}</span>
    @endif
</div>
<div>
    <label for="description">Description</label>
    <span><input required type="text" name="description" id="description" value="qu'est-ce que ce forfait mange en hiver ?"></span>
</div>
