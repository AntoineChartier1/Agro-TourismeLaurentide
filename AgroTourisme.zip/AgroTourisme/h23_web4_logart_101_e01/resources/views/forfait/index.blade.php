@extends('layouts.app')
@section ('contenu')

<h1>Forfaits</h1>


@include('forfait.list') {{-- va inserer list.blade.php --}}

@endsection
