

<h1>Liste des forfaits</h1>
<div class="liste">
    <table >
        @foreach ($forfaits as $forfait)
            <tr>
                <th>{{ $forfait->id }}</th>
                <td><a href="{{route('forfait.show', $forfait)}}">{{ $forfait->name }}</a></td>
            </tr>
        @endforeach
        <br>
    </table>
</div>
