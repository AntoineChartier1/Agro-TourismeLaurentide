@extends('layouts.app')
@section('contenu')
<h1> {{$forfait->name}}</h1>
<p>{{$forfait->description}}</p>



@endsection
