@extends('layouts.app')
@section('contenu')
<h1>Modifier le forfait: {{$forfait->name}}</h1>




@endsection
