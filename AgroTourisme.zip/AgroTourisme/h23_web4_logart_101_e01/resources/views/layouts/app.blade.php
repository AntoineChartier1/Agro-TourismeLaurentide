<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>mon app</title>
    <style>
        .liste td, .liste th{
            padding: 10px;
            border: black solid 2px;
        }
    </style>
</head>
<body>
    <div class="interface">
        @include('layouts.header')
        @include('layouts.nav')
        <main>
            <div id="app">
                @yield('contenu','Il n\'y a pas de contenu')
                {{-- inclue la @section contenu situé dans index qui lui renvoit sa réference via @extends
                     sinon affiche "il n'y a pas de contenu --}}
            </div>

        </main>
        @include('layouts.footer')
    </div>


</body>
</html>
