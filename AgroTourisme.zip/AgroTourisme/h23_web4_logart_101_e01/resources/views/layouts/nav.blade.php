<nav>
    <ul>
        <li><a href="/mrc">MRCs</a></li>
        <li><a href="/ville">Villes</a></li>
        <li><a href="/entreprise">Entreprises</a></li>
        <li><a href="/forfait">Forfaits</a></li>
        <li><a href="/user">Users</a></li>
    </ul>
</nav>
