@extends('layouts.app')
@section ('contenu')
<h2>je suis dans la section contenu des mrcs</h2>
{{-- <?php echo $mrcs[0]->name ?> --}}
{{-- <h1>Liste des taches</h1> --}}
@include('mrc.list') {{-- va inserer list.blade.php --}}

@endsection
