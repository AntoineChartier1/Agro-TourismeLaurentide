<h1>Liste des mrcs</h1>
<div class="liste">
    <table>
        <tr>
            <th>nom</th>
            <th>population</th>
        </tr>
        @foreach ($mrcs as $mrc)
        <tr>
            <td><a href="{{route('mrc.show', $mrc)}}"> {{$mrc->name}}</a></td>
            <td>{{$mrc->population}}</td>
        </tr>
        @endforeach
    </table>
</div>
