@extends('layouts.app')
@section('contenu')

<h1>{{ $mrc->name }}</h1>

<h2>Cities in {{ $mrc->name }}:</h2>
<ul>
    @foreach ($villes as $ville)
        <li><a href="{{route('ville.show', $ville)}}">{{ $ville->name }}</a></li>
    @endforeach
</ul>

@endsection
