<h1>Ajouter un user</h1>
<form action="{{ route('user.store') }}" method="POST">

    @include('user.form')
    <div><button>Créer</button></div>
</form>
