@extends('layouts.app')
@section ('contenu')
<h2>je suis dans la section contenu des USERS</h2>

{{-- {{$users[0]->name}} --}}
@include('user.create')

@endsection
