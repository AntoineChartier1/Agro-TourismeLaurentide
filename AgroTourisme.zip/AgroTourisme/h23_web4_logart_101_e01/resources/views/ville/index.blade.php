@extends('layouts.app')
@section ('contenu')

{{-- <h1>Liste des villes</h1> --}}
@include('ville.list') {{-- va inserer list.blade.php --}}

@endsection
