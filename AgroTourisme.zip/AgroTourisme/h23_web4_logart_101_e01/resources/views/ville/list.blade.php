<?php
$columns = Schema::getColumnListing('villes'); // va fetch le nom de chaque colonne
?>

<h1>Liste des villes</h1>
<div class="liste">
    <table >
        <tr>
            @foreach ($columns as $column) {{--  affiche le nom de chaque attributs de la table "villes" --}}
                <td> <?php echo $column; ?></td>
                {{-- <th>{{dd($villes[0])}}</th> --}}
            @endforeach
        </tr>
        @foreach ($villes as $ville)
            <tr>
                <th>{{ $ville->id }}</th>
                <td><a href="{{route('ville.show', $ville)}}">{{ $ville->name }}</a></td>
                <td>{{ $ville->citizen_name }}</td>
                <td>{{ $ville->mrc_id }}</td>
            </tr>
        @endforeach
        <br>
    </table>
</div>
