@extends('layouts.app')
@section('contenu')
<h1> {{$ville->name}}</h1>




@endsection
