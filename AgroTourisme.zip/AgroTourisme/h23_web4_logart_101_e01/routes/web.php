<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;
use App\Http\Controllers\MrcController;
use App\Http\Controllers\VilleController;
use App\Http\Controllers\EntrepriseController;
use App\Http\Controllers\ForfaitController;
use App\Http\Controllers\UserController;
use App\Models\Entreprise;
use App\Models\Forfait;
use App\Models\User;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// original
Route::get('/', function () {
    // return(Entreprise::with('forfaits')->find(6));
    return(Forfait::with('entreprises')->with('activites')->find(1));
    return view('layouts.app');
});

// mon test il cree une nouvelle pair d'entreprise/user a chaque refresh
Route::get('/test', function () {
    $user = User::find(2);
    $entreprise = Entreprise::find(2);

    $user->entreprises()->attach($entreprise->id);

    $entreprises = $user->entreprises()->get();

    return $entreprises;
});
// mon test pour voir les villes de chaque région
// Route::get('mrcs', function () {
//     return  view('mrcs/index');
// });

Route::resource('mrc', MrcController::class);  // écoute de tous les routes de base ( index, create, edit etc)
Route::resource('ville', VilleController::class);  // écoute de tous les routes de base ( index, create, edit etc)
Route::resource('entreprise', EntrepriseController::class);  // écoute de tous les routes de base ( index, create, edit etc)
Route::resource('user', UserController::class);  // écoute de tous les routes de base ( index, create, edit etc)


Route::group([
    'prefix'=> 'forfait',
    'controller'=> ForfaitController::class,
    'where'=> ['forfait'=>"[0-9]+"],
    'as'=>"forfait.",
], function(){
    Route::get("", 'index')
    ->name('index'); // nom lorsque j'utilise Route dans les views
    Route::get("{forfait}", 'show')
    ->name('show');
    Route::get("delete/{forfait}", 'destroy')
    ->name('destroy');
    Route::get("update/{forfait}", 'update')
    ->name('update');
    Route::get("create", 'create')
    ->name('create');
    Route::get("store", 'store')
    ->name('store');
});



