
<?php $__env->startSection('contenu'); ?>
<h2>je suis dans la section contenu des mrcs</h2>


<?php echo $__env->make('mrc.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\EcoleLocal\Web4\AgroTourisme\h23_web4_logart_101_e01\resources\views/mrc/index.blade.php ENDPATH**/ ?>