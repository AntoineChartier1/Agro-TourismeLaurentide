<?php $__env->startSection('contenu'); ?>
<h2>je suis dans la section contenu des USERS</h2>


<?php echo $__env->make('user.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CHAA1363491\24-avril\agro-tourisme13\resources\views/user/index.blade.php ENDPATH**/ ?>