<h1>Liste des regions</h1>
<div class="liste">
    <table>
        <tr>
            <th>nom</th>
            <th>population</th>
        </tr>
        <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($region->name); ?></td>
            <td><?php echo e($region->population); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php /**PATH D:\EcoleLocal\Web4\agro-tourismeMoinsVendor\resources\views/region/list.blade.php ENDPATH**/ ?>