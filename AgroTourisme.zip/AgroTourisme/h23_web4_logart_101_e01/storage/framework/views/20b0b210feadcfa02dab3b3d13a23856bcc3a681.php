<nav>
    <ul>
        <li><a href="/mrc">MRCs</a></li>
        <li><a href="/ville">Villes</a></li>
        <li><a href="/entreprise">Entreprises</a></li>
        <li><a href="/user">Users</a></li>
    </ul>
</nav>
<?php /**PATH D:\CHAA1363491\24-avril\agro-tourisme13\resources\views/layouts/nav.blade.php ENDPATH**/ ?>