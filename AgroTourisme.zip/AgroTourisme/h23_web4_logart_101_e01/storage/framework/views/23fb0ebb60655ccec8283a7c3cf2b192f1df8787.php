<h1>Ajouter un user</h1>
<form action="<?php echo e(route('user.store')); ?>" method="POST">

    <?php echo $__env->make('user.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div><button>Créer</button></div>
</form>
<?php /**PATH D:\1363491\web4\Cours13\agro-tourismeMoinsVendor\resources\views/user/create.blade.php ENDPATH**/ ?>