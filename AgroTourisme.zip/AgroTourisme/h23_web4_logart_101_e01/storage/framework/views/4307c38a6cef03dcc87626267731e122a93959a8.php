<h1>Liste des mrcs</h1>
<div class="liste">
    <table>
        <tr>
            <th>nom</th>
            <th>population</th>
        </tr>
        <?php $__currentLoopData = $mrcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mrc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><a href="<?php echo e(route('mrc.show', $mrc)); ?>"> <?php echo e($mrc->name); ?></a></td>
            <td><?php echo e($mrc->population); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php /**PATH D:\CHAA1363491\24-avril\agro-tourisme13\resources\views/mrc/list.blade.php ENDPATH**/ ?>