<nav>
    <ul>
        <li><a href="/region">Regions</a></li>
        <li><a href="/ville">Villes</a></li>
        <li><a href="/entreprise">Entreprises</a></li>
        <li><a href="/user">Users</a></li>
    </ul>
</nav>
<?php /**PATH D:\1363491\web4\Cours13\agro-tourismeMoinsVendor\resources\views/layouts/nav.blade.php ENDPATH**/ ?>