
<?php $__env->startSection('contenu'); ?>

<h1><?php echo e($region->name); ?></h1>

<h2>Cities in <?php echo e($region->name); ?>:</h2>
<ul>
    <?php $__currentLoopData = $villes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ville): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e(route('ville.show', $ville)); ?>"><?php echo e($ville->name); ?></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CHAA1363491\agro-tourismeMoinsVendor\resources\views/region/show.blade.php ENDPATH**/ ?>