<header>
    <h1>Header Layouts</h1>
</header>
<?php /**PATH D:\1363491\web4\Cours13\agro-tourismeMoinsVendor\resources\views/layouts/header.blade.php ENDPATH**/ ?>