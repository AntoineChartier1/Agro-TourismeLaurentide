

<h1>Liste des forfaits</h1>
<div class="liste">
    <table >
        <?php $__currentLoopData = $forfaits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forfait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($forfait->id); ?></th>
                <td><a href="<?php echo e(route('forfait.show', $forfait)); ?>"><?php echo e($forfait->name); ?></a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <br>
    </table>
</div>
<?php /**PATH D:\EcoleLocal\Web4\AgroTourisme\h23_web4_logart_101_e01\resources\views/forfait/list.blade.php ENDPATH**/ ?>