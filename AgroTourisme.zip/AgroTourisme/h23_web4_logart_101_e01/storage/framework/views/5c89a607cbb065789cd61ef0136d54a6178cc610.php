<?php $__env->startSection('contenu'); ?>
<h1> <?php echo e($ville->name); ?></h1>
<h1> <?php echo e($regions[$ville->region_id]->name); ?></h1>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\EcoleLocal\Web4\agro-tourismeMoinsVendor\resources\views/ville/show.blade.php ENDPATH**/ ?>