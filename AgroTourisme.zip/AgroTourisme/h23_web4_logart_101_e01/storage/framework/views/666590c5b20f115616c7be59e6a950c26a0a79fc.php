<header>
    <h1>CECI EST UN HEADER dans layout header</h1>
</header>
<?php /**PATH D:\CHAA1363491\agro-tourismeMoinsVendor\resources\views/layouts/header.blade.php ENDPATH**/ ?>