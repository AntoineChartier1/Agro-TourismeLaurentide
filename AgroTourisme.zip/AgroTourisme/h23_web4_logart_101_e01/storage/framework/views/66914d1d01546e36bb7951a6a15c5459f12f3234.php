<header>
    <h1>CECI EST UN HEADER dans layout header</h1>
</header>
<?php /**PATH D:\EcoleLocal\Web4\agro-tourismeMoinsVendor\resources\views/layouts/header.blade.php ENDPATH**/ ?>