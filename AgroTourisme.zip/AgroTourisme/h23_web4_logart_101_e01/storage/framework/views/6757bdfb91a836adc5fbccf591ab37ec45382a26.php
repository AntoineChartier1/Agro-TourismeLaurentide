<header>
    <h1>Header Layouts</h1>
</header>
<?php /**PATH D:\EcoleLocal\Web4\AgroTourisme\h23_web4_logart_101_e01\resources\views/layouts/header.blade.php ENDPATH**/ ?>