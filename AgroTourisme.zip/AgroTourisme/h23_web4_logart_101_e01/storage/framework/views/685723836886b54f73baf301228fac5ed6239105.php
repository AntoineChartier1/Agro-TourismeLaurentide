<h1>Ajouter un user</h1>
<form action="<?php echo e(route('user.store')); ?>" method="POST">

    <?php echo $__env->make('user.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div><button>Créer</button></div>
</form>
<?php /**PATH D:\EcoleLocal\Web4\AgroTourisme\h23_web4_logart_101_e01\resources\views/user/create.blade.php ENDPATH**/ ?>