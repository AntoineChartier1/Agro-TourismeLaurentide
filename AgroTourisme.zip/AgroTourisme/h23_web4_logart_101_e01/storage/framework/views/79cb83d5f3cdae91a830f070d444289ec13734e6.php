<?php $__env->startSection('contenu'); ?>


<?php echo $__env->make('ville.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CHAA1363491\agro-tourismeMoinsVendor\resources\views/ville/index.blade.php ENDPATH**/ ?>