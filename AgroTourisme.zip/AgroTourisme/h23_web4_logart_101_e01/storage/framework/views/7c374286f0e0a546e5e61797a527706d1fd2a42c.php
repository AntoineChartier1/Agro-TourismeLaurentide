<h1>Liste des mrcs</h1>
<div class="liste">
    <table>
        <tr>
            <th>nom</th>
            <th>population</th>
        </tr>
        <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><a href="<?php echo e(route('region.show', $region)); ?>"> <?php echo e($region->name); ?></a></td>
            <td><?php echo e($region->population); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php /**PATH D:\CHAA1363491\24-avril\agro-tourisme13\resources\views/mrc/list.blade.php ENDPATH**/ ?>
