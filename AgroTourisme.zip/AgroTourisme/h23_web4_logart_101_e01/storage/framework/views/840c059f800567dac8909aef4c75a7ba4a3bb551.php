<form action="<?php echo e(route('entreprise.store')); ?>" method="POST" >
    <?php echo csrf_field(); ?>

    <label for="name">Name:</label>
    <input type="text" name="name" id="name">
    <br/>

    <label for="description">Description:</label>
    <textarea name="description" id="description"></textarea>
    <br/>

    <button type="submit">Ajouter</button>
</form>
<?php /**PATH D:\EcoleLocal\Web4\AgroTourisme\h23_web4_logart_101_e01\resources\views/entreprise/create.blade.php ENDPATH**/ ?>