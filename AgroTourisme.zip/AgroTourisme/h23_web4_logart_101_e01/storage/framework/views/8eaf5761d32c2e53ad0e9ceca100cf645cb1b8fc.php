<?php echo csrf_field(); ?>
<?php if(count($errors)): ?>
<div class="errors"> Il y a des erreurs dans le formulaire</div>
<?php endif; ?>

<div>
    <label for="name">Prénom</label>
    <span><input required type="text" name="name" id="name" value="Joe"></span>
    <?php if($errors->has('name')): ?>
        <span class="error"><?php echo e($errors->first('name')); ?></span>
    <?php endif; ?>
</div>
<div>
    <label for="naissance">Naissance</label>
    <span><input required type="date" name="naissance" id="naissance" value="1995-05-12"></span>
</div>
<div>
    <label for="email">Courriel</label>
    <span><input type="email" name="email" id="email" value=""></span>
</div>
<div>
    <label for="tel">Numéro de telephone</label>
    <span><input type="tel" name="tel" id="tel" value="911"></span>
</div>
<div>
    <label for="code_postal">Code Postal</label>
    <span><input pattern="[a-zA-Z][0-9][a-zA-Z][ \._-][0-9][a-zA-Z][0-9]" type="text" name="code_postal" id="code_postal" value="A1B 2C3"></span>
</div>
<?php /**PATH D:\EcoleLocal\Web4\AgroTourisme\h23_web4_logart_101_e01\resources\views/user/form.blade.php ENDPATH**/ ?>