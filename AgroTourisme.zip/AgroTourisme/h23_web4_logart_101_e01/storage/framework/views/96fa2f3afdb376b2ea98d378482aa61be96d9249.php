<header>
    <h1>Header Layouts</h1>
</header>
<?php /**PATH D:\CHAA1363491\24-avril\agro-tourisme13\resources\views/layouts/header.blade.php ENDPATH**/ ?>