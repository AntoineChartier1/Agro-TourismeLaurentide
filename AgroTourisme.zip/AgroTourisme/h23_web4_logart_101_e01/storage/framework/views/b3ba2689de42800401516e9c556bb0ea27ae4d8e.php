<nav>
    <ul>
        <li><a href="/region">Regions</a></li>
        <li><a href="/ville">Villes</a></li>
    </ul>
</nav>
<?php /**PATH D:\EcoleLocal\Web4\agro-tourismeMoinsVendor\resources\views/layouts/nav.blade.php ENDPATH**/ ?>