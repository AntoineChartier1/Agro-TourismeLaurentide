<?php
$columns = Schema::getColumnListing('villes'); // va fetch le nom de chaque colonne
?>

<h1>Liste des villes</h1>
<div class="liste">
    <table >
        <tr>
            <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <td> <?php echo $column; ?></td>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <?php $__currentLoopData = $villes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ville): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($ville->id); ?></th>
                <td><a href="<?php echo e(route('ville.show', $ville)); ?>"><?php echo e($ville->name); ?></a></td>
                <td><?php echo e($ville->citizen_name); ?></td>
                <td><?php echo e($ville->mrc_id); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <br>
    </table>
</div>
<?php /**PATH D:\EcoleLocal\Web4\AgroTourisme\h23_web4_logart_101_e01\resources\views/ville/list.blade.php ENDPATH**/ ?>