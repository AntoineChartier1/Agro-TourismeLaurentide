<nav>
    <ul>
        <li><a href="/mrc">MRCs</a></li>
        <li><a href="/ville">Villes</a></li>
        <li><a href="/entreprise">Entreprises</a></li>
        <li><a href="/forfait">Forfaits</a></li>
        <li><a href="/user">Users</a></li>
    </ul>
</nav>
<?php /**PATH D:\EcoleLocal\Web4\AgroTourisme\h23_web4_logart_101_e01\resources\views/layouts/nav.blade.php ENDPATH**/ ?>