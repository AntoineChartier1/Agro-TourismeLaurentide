<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>mon app</title>
    <style>
        .liste td, .liste th{
            padding: 10px;
            border: black solid 2px;
        }
    </style>
</head>
<body>
    <div class="interface">
        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <main>
            <div id="app">
                <?php echo $__env->yieldContent('contenu','Il n\'y a pas de contenu'); ?>
                
            </div>

        </main>
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>



</body>
</html>
<?php /**PATH D:\EcoleLocal\Web4\agro-tourismeMoinsVendor\resources\views/layouts/app.blade.php ENDPATH**/ ?>